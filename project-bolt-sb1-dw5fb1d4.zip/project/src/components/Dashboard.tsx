import React from 'react';
import { BarChart3, TrendingUp, AlertTriangle, CheckCircle, Calendar } from 'lucide-react';

interface VehicleDocument {
  type: string;
  isValid: boolean;
  expirationDate: string;
  daysUntilExpiration: number;
}

interface TruckRegistration {
  id: string;
  plate: string;
  driver: string;
  driverLicense: string;
  vehicleCondition: string;
  observations: string;
  entryTime: string;
  documents: VehicleDocument[];
}

interface DashboardProps {
  registrations: TruckRegistration[];
}

const Dashboard: React.FC<DashboardProps> = ({ registrations }) => {
  const getStats = () => {
    const today = new Date();
    const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    
    const todayRegistrations = registrations.filter(reg => 
      new Date(reg.entryTime) >= todayStart
    );

    const conditionCounts = registrations.reduce((acc, reg) => {
      acc[reg.vehicleCondition] = (acc[reg.vehicleCondition] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const documentStats = registrations.reduce((acc, reg) => {
      reg.documents.forEach(doc => {
        if (!doc.isValid) {
          acc.expired++;
        } else if (doc.daysUntilExpiration <= 30) {
          acc.expiringSoon++;
        }
      });
      return acc;
    }, { expired: 0, expiringSoon: 0 });

    return {
      total: registrations.length,
      today: todayRegistrations.length,
      conditionCounts,
      documentStats
    };
  };

  const stats = getStats();

  const getConditionColor = (condition: string) => {
    switch (condition) {
      case 'excellent': return 'text-green-600';
      case 'good': return 'text-blue-600';
      case 'fair': return 'text-yellow-600';
      case 'poor': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getConditionLabel = (condition: string) => {
    switch (condition) {
      case 'excellent': return 'Excelente';
      case 'good': return 'Bueno';
      case 'fair': return 'Regular';
      case 'poor': return 'Malo';
      default: return condition;
    }
  };

  return (
    <div className="space-y-6">
      {/* Estadísticas principales */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="flex items-center gap-3">
            <div className="bg-blue-100 p-3 rounded-lg">
              <BarChart3 className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Total Registros</p>
              <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="flex items-center gap-3">
            <div className="bg-green-100 p-3 rounded-lg">
              <Calendar className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Hoy</p>
              <p className="text-2xl font-bold text-gray-900">{stats.today}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="flex items-center gap-3">
            <div className="bg-red-100 p-3 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Docs. Vencidos</p>
              <p className="text-2xl font-bold text-gray-900">{stats.documentStats.expired}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="flex items-center gap-3">
            <div className="bg-yellow-100 p-3 rounded-lg">
              <TrendingUp className="w-6 h-6 text-yellow-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Por Vencer</p>
              <p className="text-2xl font-bold text-gray-900">{stats.documentStats.expiringSoon}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Estado de vehículos */}
      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Estado de Vehículos</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Object.entries(stats.conditionCounts).map(([condition, count]) => (
            <div key={condition} className="text-center">
              <div className={`text-2xl font-bold ${getConditionColor(condition)}`}>
                {count}
              </div>
              <p className="text-sm text-gray-600">{getConditionLabel(condition)}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Alertas de documentos */}
      {(stats.documentStats.expired > 0 || stats.documentStats.expiringSoon > 0) && (
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Alertas de Documentos</h3>
          <div className="space-y-3">
            {stats.documentStats.expired > 0 && (
              <div className="flex items-center gap-3 p-3 bg-red-50 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-red-600" />
                <div>
                  <p className="font-medium text-red-900">Documentos Vencidos</p>
                  <p className="text-sm text-red-700">{stats.documentStats.expired} documento{stats.documentStats.expired > 1 ? 's' : ''} vencido{stats.documentStats.expired > 1 ? 's' : ''}</p>
                </div>
              </div>
            )}
            {stats.documentStats.expiringSoon > 0 && (
              <div className="flex items-center gap-3 p-3 bg-yellow-50 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-yellow-600" />
                <div>
                  <p className="font-medium text-yellow-900">Documentos por Vencer</p>
                  <p className="text-sm text-yellow-700">{stats.documentStats.expiringSoon} documento{stats.documentStats.expiringSoon > 1 ? 's' : ''} vence{stats.documentStats.expiringSoon > 1 ? 'n' : ''} en los próximos 30 días</p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Registros recientes */}
      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Registros Recientes</h3>
        {registrations.length > 0 ? (
          <div className="space-y-3">
            {registrations.slice(0, 5).map((registration) => (
              <div key={registration.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="bg-green-100 p-2 rounded">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{registration.plate}</p>
                    <p className="text-sm text-gray-600">{registration.driver}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-900">
                    {new Date(registration.entryTime).toLocaleDateString('es-CO')}
                  </p>
                  <p className="text-sm text-gray-600">
                    {new Date(registration.entryTime).toLocaleTimeString('es-CO', { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500 text-center py-8">No hay registros disponibles</p>
        )}
      </div>
    </div>
  );
};

export default Dashboard;