import React from 'react';
import { Truck, FileText, Plus, BarChart3, LogOut } from 'lucide-react';

interface NavigationProps {
  currentView: 'new-vehicle' | 'inspection' | 'admin';
  onViewChange: (view: 'new-vehicle' | 'inspection' | 'admin') => void;
  isAdmin?: boolean;
  onLogout?: () => void;
}

const Navigation: React.FC<NavigationProps> = ({ 
  currentView, 
  onViewChange, 
  isAdmin = false,
  onLogout 
}) => {
  const navItems = [
    {
      id: 'new-vehicle',
      label: 'Vehículo Nuevo/Externo',
      icon: Plus,
      description: 'Registro rápido de ingreso'
    },
    {
      id: 'inspection',
      label: 'Inspección de Vehículo',
      icon: FileText,
      description: 'Checklist completo'
    }
  ];

  if (isAdmin) {
    navItems.push({
      id: 'admin',
      label: 'Panel Administrativo',
      icon: BarChart3,
      description: 'Gestión y reportes'
    });
  }

  return (
    <nav className="bg-white border-b border-florius-light">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <div className="flex space-x-8">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => onViewChange(item.id as any)}
                  className={`flex items-center gap-2 px-3 py-4 text-sm font-medium border-b-2 transition-colors ${
                    currentView === item.id
                      ? 'border-florius-primary text-florius-primary'
                      : 'border-transparent text-florius-secondary hover:text-florius-primary hover:border-florius-accent'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <div className="text-left">
                    <div>{item.label}</div>
                    <div className="text-xs opacity-75">{item.description}</div>
                  </div>
                </button>
              );
            })}
          </div>
          
          {isAdmin && onLogout && (
            <button
              onClick={onLogout}
              className="flex items-center gap-2 px-3 py-2 text-red-600 hover:bg-red-50 rounded-md transition-colors"
            >
              <LogOut className="w-4 h-4" />
              Cerrar Sesión
            </button>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navigation;