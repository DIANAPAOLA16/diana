import React from 'react';

interface LogoProps {
  className?: string;
  showText?: boolean;
}

const Logo: React.FC<LogoProps> = ({ className = "w-10 h-10", showText = true }) => {
  return (
    <div className="flex items-center gap-3">
      <img 
        src="https://floriusflowers.com/wp-content/uploads/2023/05/cropped-Florius-Flowers-Logo-32x32.png" 
        alt="Florius Flowers Logo" 
        className={className}
        onError={(e) => {
          // Fallback si la imagen no carga
          e.currentTarget.style.display = 'none';
          e.currentTarget.nextElementSibling?.classList.remove('hidden');
        }}
      />
      <div className="w-10 h-10 bg-florius-primary rounded-lg flex items-center justify-center hidden">
        <span className="text-white font-bold text-lg">F</span>
      </div>
      {showText && (
        <div>
          <h1 className="text-xl font-bold text-florius-dark">Florius Flowers</h1>
          <p className="text-sm text-florius-secondary">Sistema de Vehículos</p>
        </div>
      )}
    </div>
  );
};

export default Logo;