import React, { useState } from 'react';
import { Truck, FileText, AlertCircle, CheckCircle, Clock, User, Calendar } from 'lucide-react';

interface VehicleDocument {
  type: string;
  isValid: boolean;
  expirationDate: string;
  daysUntilExpiration: number;
}

interface TruckRegistration {
  plate: string;
  driver: string;
  driverLicense: string;
  vehicleCondition: string;
  observations: string;
  entryTime: string;
  documents: VehicleDocument[];
}

interface TruckRegistrationFormProps {
  onSubmit: (registration: TruckRegistration) => void;
}

const TruckRegistrationForm: React.FC<TruckRegistrationFormProps> = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    plate: '',
    driver: '',
    driverLicense: '',
    vehicleCondition: '',
    observations: ''
  });

  const [documents, setDocuments] = useState<VehicleDocument[]>([]);
  const [loading, setLoading] = useState(false);
  const [showDocuments, setShowDocuments] = useState(false);

  const vehicleConditions = [
    { value: 'excellent', label: 'Excelente', color: 'bg-green-100 text-green-800' },
    { value: 'good', label: 'Bueno', color: 'bg-blue-100 text-blue-800' },
    { value: 'fair', label: 'Regular', color: 'bg-yellow-100 text-yellow-800' },
    { value: 'poor', label: 'Malo', color: 'bg-red-100 text-red-800' }
  ];

  // Simulación de consulta de documentos vehiculares
  const checkVehicleDocuments = async (plate: string): Promise<VehicleDocument[]> => {
    setLoading(true);
    
    // Simulación de delay de API
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const mockDocuments: VehicleDocument[] = [
      {
        type: 'SOAT',
        isValid: Math.random() > 0.3,
        expirationDate: '2024-12-15',
        daysUntilExpiration: Math.floor(Math.random() * 365)
      },
      {
        type: 'Tecnomecánica',
        isValid: Math.random() > 0.2,
        expirationDate: '2024-11-20',
        daysUntilExpiration: Math.floor(Math.random() * 300)
      },
      {
        type: 'Tarjeta de Propiedad',
        isValid: Math.random() > 0.1,
        expirationDate: '2025-03-10',
        daysUntilExpiration: Math.floor(Math.random() * 400)
      },
      {
        type: 'Revisión Gases',
        isValid: Math.random() > 0.4,
        expirationDate: '2024-10-30',
        daysUntilExpiration: Math.floor(Math.random() * 180)
      }
    ];

    setLoading(false);
    return mockDocuments;
  };

  const handlePlateChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const plate = e.target.value.toUpperCase();
    setFormData({ ...formData, plate });
    
    if (plate.length >= 6) {
      const docs = await checkVehicleDocuments(plate);
      setDocuments(docs);
      setShowDocuments(true);
    } else {
      setShowDocuments(false);
      setDocuments([]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const registration: TruckRegistration = {
      ...formData,
      entryTime: new Date().toISOString(),
      documents
    };
    
    onSubmit(registration);
    
    // Reset form
    setFormData({
      plate: '',
      driver: '',
      driverLicense: '',
      vehicleCondition: '',
      observations: ''
    });
    setDocuments([]);
    setShowDocuments(false);
  };

  const getDocumentIcon = (doc: VehicleDocument) => {
    if (doc.isValid) {
      return <CheckCircle className="w-5 h-5 text-green-600" />;
    } else if (doc.daysUntilExpiration <= 30) {
      return <AlertCircle className="w-5 h-5 text-red-600" />;
    } else {
      return <Clock className="w-5 h-5 text-yellow-600" />;
    }
  };

  const getDocumentStatus = (doc: VehicleDocument) => {
    if (!doc.isValid) return 'Vencido';
    if (doc.daysUntilExpiration <= 30) return 'Por vencer';
    return 'Vigente';
  };

  const getDocumentColor = (doc: VehicleDocument) => {
    if (!doc.isValid) return 'bg-red-100 text-red-800';
    if (doc.daysUntilExpiration <= 30) return 'bg-yellow-100 text-yellow-800';
    return 'bg-green-100 text-green-800';
  };

  const isFormValid = formData.plate && formData.driver && formData.driverLicense && formData.vehicleCondition;

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-lg">
      <div className="flex items-center gap-3 mb-6">
        <Truck className="w-8 h-8 text-green-600" />
        <h2 className="text-2xl font-bold text-gray-900">Registro de Ingreso de Camiones</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Placa del Vehículo */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Placa del Vehículo *
            </label>
            <input
              type="text"
              value={formData.plate}
              onChange={handlePlateChange}
              placeholder="Ej: ABC123"
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent uppercase"
              required
            />
            {loading && (
              <div className="mt-2 flex items-center gap-2 text-blue-600">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                <span className="text-sm">Verificando documentos...</span>
              </div>
            )}
          </div>

          {/* Conductor */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nombre del Conductor *
            </label>
            <div className="relative">
              <User className="absolute left-3 top-2.5 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={formData.driver}
                onChange={(e) => setFormData({ ...formData, driver: e.target.value })}
                placeholder="Nombre completo"
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                required
              />
            </div>
          </div>

          {/* Licencia de Conducir */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Número de Licencia *
            </label>
            <input
              type="text"
              value={formData.driverLicense}
              onChange={(e) => setFormData({ ...formData, driverLicense: e.target.value })}
              placeholder="Número de licencia"
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
              required
            />
          </div>

          {/* Estado del Vehículo */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Estado del Vehículo *
            </label>
            <select
              value={formData.vehicleCondition}
              onChange={(e) => setFormData({ ...formData, vehicleCondition: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
              required
            >
              <option value="">Seleccionar estado</option>
              {vehicleConditions.map((condition) => (
                <option key={condition.value} value={condition.value}>
                  {condition.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Observaciones */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Observaciones
          </label>
          <textarea
            value={formData.observations}
            onChange={(e) => setFormData({ ...formData, observations: e.target.value })}
            placeholder="Observaciones adicionales sobre el vehículo o conductor"
            rows={3}
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
        </div>

        {/* Documentos del Vehículo */}
        {showDocuments && documents.length > 0 && (
          <div className="bg-gray-50 p-6 rounded-lg">
            <div className="flex items-center gap-2 mb-4">
              <FileText className="w-5 h-5 text-gray-600" />
              <h3 className="text-lg font-semibold text-gray-900">Estado de Documentos</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {documents.map((doc, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                  <div className="flex items-center gap-3">
                    {getDocumentIcon(doc)}
                    <div>
                      <p className="font-medium text-gray-900">{doc.type}</p>
                      <p className="text-sm text-gray-600">Vence: {doc.expirationDate}</p>
                    </div>
                  </div>
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${getDocumentColor(doc)}`}>
                    {getDocumentStatus(doc)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Botón de Envío */}
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={!isFormValid}
            className={`px-6 py-2 rounded-md font-medium transition-colors ${
              isFormValid
                ? 'bg-green-600 text-white hover:bg-green-700 focus:ring-2 focus:ring-green-500'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            Registrar Ingreso
          </button>
        </div>
      </form>
    </div>
  );
};

export default TruckRegistrationForm;