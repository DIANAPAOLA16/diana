import React from 'react';
import { Calendar, User, FileText, AlertTriangle, CheckCircle } from 'lucide-react';

interface VehicleDocument {
  type: string;
  isValid: boolean;
  expirationDate: string;
  daysUntilExpiration: number;
}

interface TruckRegistration {
  id: string;
  plate: string;
  driver: string;
  driverLicense: string;
  vehicleCondition: string;
  observations: string;
  entryTime: string;
  documents: VehicleDocument[];
}

interface RegistrationsListProps {
  registrations: TruckRegistration[];
}

const RegistrationsList: React.FC<RegistrationsListProps> = ({ registrations }) => {
  const getConditionColor = (condition: string) => {
    switch (condition) {
      case 'excellent': return 'bg-green-100 text-green-800';
      case 'good': return 'bg-blue-100 text-blue-800';
      case 'fair': return 'bg-yellow-100 text-yellow-800';
      case 'poor': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getConditionLabel = (condition: string) => {
    switch (condition) {
      case 'excellent': return 'Excelente';
      case 'good': return 'Bueno';
      case 'fair': return 'Regular';
      case 'poor': return 'Malo';
      default: return condition;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-CO', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getDocumentSummary = (documents: VehicleDocument[]) => {
    const expired = documents.filter(doc => !doc.isValid).length;
    const expiringSoon = documents.filter(doc => doc.isValid && doc.daysUntilExpiration <= 30).length;
    
    return { expired, expiringSoon };
  };

  if (registrations.length === 0) {
    return (
      <div className="text-center py-12">
        <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-600 text-lg">No hay registros de ingreso</p>
        <p className="text-gray-400">Los registros aparecerán aquí cuando se registre el primer camión</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="text-xl font-semibold text-gray-900 mb-4">
        Registros de Ingreso ({registrations.length})
      </h3>
      
      <div className="grid gap-4">
        {registrations.map((registration) => {
          const { expired, expiringSoon } = getDocumentSummary(registration.documents);
          
          return (
            <div key={registration.id} className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
                <div className="flex items-center gap-3">
                  <div className="bg-green-100 p-2 rounded-lg">
                    <User className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 text-lg">{registration.plate}</h4>
                    <p className="text-gray-600">{registration.driver}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-gray-500" />
                  <span className="text-sm text-gray-600">{formatDate(registration.entryTime)}</span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div>
                  <p className="text-sm text-gray-500 mb-1">Estado del Vehículo</p>
                  <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getConditionColor(registration.vehicleCondition)}`}>
                    {getConditionLabel(registration.vehicleCondition)}
                  </span>
                </div>
                
                <div>
                  <p className="text-sm text-gray-500 mb-1">Licencia</p>
                  <p className="text-sm font-medium text-gray-900">{registration.driverLicense}</p>
                </div>
                
                <div>
                  <p className="text-sm text-gray-500 mb-1">Estado de Documentos</p>
                  <div className="flex items-center gap-2">
                    {expired > 0 && (
                      <span className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium rounded-full bg-red-100 text-red-800">
                        <AlertTriangle className="w-3 h-3" />
                        {expired} vencido{expired > 1 ? 's' : ''}
                      </span>
                    )}
                    {expiringSoon > 0 && (
                      <span className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium rounded-full bg-yellow-100 text-yellow-800">
                        <AlertTriangle className="w-3 h-3" />
                        {expiringSoon} por vencer
                      </span>
                    )}
                    {expired === 0 && expiringSoon === 0 && (
                      <span className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">
                        <CheckCircle className="w-3 h-3" />
                        Documentos al día
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {registration.observations && (
                <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-500 mb-1">Observaciones</p>
                  <p className="text-sm text-gray-800">{registration.observations}</p>
                </div>
              )}

              {/* Detalles de documentos */}
              <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-2">
                {registration.documents.map((doc, index) => (
                  <div key={index} className="text-center p-2 bg-gray-50 rounded">
                    <div className="flex justify-center mb-1">
                      {doc.isValid ? (
                        <CheckCircle className="w-4 h-4 text-green-600" />
                      ) : (
                        <AlertTriangle className="w-4 h-4 text-red-600" />
                      )}
                    </div>
                    <p className="text-xs font-medium text-gray-900">{doc.type}</p>
                    <p className="text-xs text-gray-600">{doc.expirationDate}</p>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default RegistrationsList;