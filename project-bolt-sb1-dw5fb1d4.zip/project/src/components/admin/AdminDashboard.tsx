import React from 'react';
import { BarChart3, TrendingUp, AlertTriangle, CheckCircle, Calendar, Download } from 'lucide-react';
import { TruckInspection } from '../../types';
import * as XLSX from 'xlsx';

interface AdminDashboardProps {
  inspections: TruckInspection[];
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ inspections }) => {
  const getStats = () => {
    const today = new Date();
    const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    
    const todayInspections = inspections.filter(inspection => 
      new Date(inspection.createdAt) >= todayStart
    );

    const documentStats = inspections.reduce((acc, inspection) => {
      inspection.vehicleInfo.documents.forEach(doc => {
        if (!doc.isValid) {
          acc.expired++;
        } else if (doc.daysUntilExpiration <= 30) {
          acc.expiringSoon++;
        }
      });
      return acc;
    }, { expired: 0, expiringSoon: 0 });

    const defectStats = inspections.reduce((acc, inspection) => {
      acc.total += inspection.defects.length;
      inspection.defects.forEach(defect => {
        acc[defect.severity] = (acc[defect.severity] || 0) + 1;
      });
      return acc;
    }, { total: 0, low: 0, medium: 0, high: 0 });

    return {
      total: inspections.length,
      today: todayInspections.length,
      documentStats,
      defectStats
    };
  };

  const exportToExcel = () => {
    const exportData = inspections.map(inspection => ({
      'Fecha': new Date(inspection.createdAt).toLocaleDateString('es-CO'),
      'Hora': new Date(inspection.createdAt).toLocaleTimeString('es-CO'),
      'Placa': inspection.plate,
      'Conductor': inspection.driverName,
      'Licencia': inspection.driverLicense,
      'Marca': inspection.vehicleInfo.brand,
      'Modelo': inspection.vehicleInfo.model,
      'Año': inspection.vehicleInfo.year,
      'VIN': inspection.vehicleInfo.vin,
      'Kilometraje': inspection.currentKilometers,
      'Próximo Servicio (Km)': inspection.nextServiceKm,
      'Fecha Próximo Servicio': inspection.nextServiceDate,
      'Defectos Encontrados': inspection.defects.length,
      'Defectos Graves': inspection.defects.filter(d => d.severity === 'high').length,
      'Neumáticos OK': inspection.checklist.tiresGoodCondition ? 'Sí' : 'No',
      'Carrocería OK': inspection.checklist.bodyNoDamage ? 'Sí' : 'No',
      'Luces OK': inspection.checklist.lightsOperational ? 'Sí' : 'No',
      'Tanque Lleno': inspection.checklist.fullTank ? 'Sí' : 'No',
      'Firma': inspection.driverSignature,
      'SOAT Vigente': inspection.vehicleInfo.documents.find(d => d.type === 'SOAT')?.isValid ? 'Sí' : 'No',
      'Tecnomecánica Vigente': inspection.vehicleInfo.documents.find(d => d.type === 'Tecnomecánica')?.isValid ? 'Sí' : 'No'
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Inspecciones');
    
    const fileName = `inspecciones_vehiculos_${new Date().toISOString().split('T')[0]}.xlsx`;
    XLSX.writeFile(wb, fileName);
  };

  const stats = getStats();

  return (
    <div className="space-y-6">
      {/* Header con botón de exportar */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Dashboard Administrativo</h2>
          <p className="text-gray-600">Resumen de inspecciones vehiculares</p>
        </div>
        <button
          onClick={exportToExcel}
          className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
        >
          <Download className="w-4 h-4" />
          Exportar Excel
        </button>
      </div>

      {/* Estadísticas principales */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="flex items-center gap-3">
            <div className="bg-blue-100 p-3 rounded-lg">
              <BarChart3 className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Total Inspecciones</p>
              <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="flex items-center gap-3">
            <div className="bg-green-100 p-3 rounded-lg">
              <Calendar className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Hoy</p>
              <p className="text-2xl font-bold text-gray-900">{stats.today}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="flex items-center gap-3">
            <div className="bg-red-100 p-3 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Docs. Vencidos</p>
              <p className="text-2xl font-bold text-gray-900">{stats.documentStats.expired}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="flex items-center gap-3">
            <div className="bg-yellow-100 p-3 rounded-lg">
              <TrendingUp className="w-6 h-6 text-yellow-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Por Vencer</p>
              <p className="text-2xl font-bold text-gray-900">{stats.documentStats.expiringSoon}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Estadísticas de defectos */}
      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Estadísticas de Defectos</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">{stats.defectStats.total}</div>
            <p className="text-sm text-gray-600">Total Defectos</p>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-red-600">{stats.defectStats.high}</div>
            <p className="text-sm text-gray-600">Graves</p>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">{stats.defectStats.medium}</div>
            <p className="text-sm text-gray-600">Moderados</p>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-yellow-600">{stats.defectStats.low}</div>
            <p className="text-sm text-gray-600">Leves</p>
          </div>
        </div>
      </div>

      {/* Alertas de documentos */}
      {(stats.documentStats.expired > 0 || stats.documentStats.expiringSoon > 0) && (
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Alertas de Documentos</h3>
          <div className="space-y-3">
            {stats.documentStats.expired > 0 && (
              <div className="flex items-center gap-3 p-3 bg-red-50 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-red-600" />
                <div>
                  <p className="font-medium text-red-900">Documentos Vencidos</p>
                  <p className="text-sm text-red-700">{stats.documentStats.expired} documento{stats.documentStats.expired > 1 ? 's' : ''} vencido{stats.documentStats.expired > 1 ? 's' : ''}</p>
                </div>
              </div>
            )}
            {stats.documentStats.expiringSoon > 0 && (
              <div className="flex items-center gap-3 p-3 bg-yellow-50 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-yellow-600" />
                <div>
                  <p className="font-medium text-yellow-900">Documentos por Vencer</p>
                  <p className="text-sm text-yellow-700">{stats.documentStats.expiringSoon} documento{stats.documentStats.expiringSoon > 1 ? 's' : ''} vence{stats.documentStats.expiringSoon > 1 ? 'n' : ''} en los próximos 30 días</p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Inspecciones recientes */}
      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Inspecciones Recientes</h3>
        {inspections.length > 0 ? (
          <div className="space-y-3">
            {inspections.slice(0, 5).map((inspection) => (
              <div key={inspection.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="bg-green-100 p-2 rounded">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{inspection.plate}</p>
                    <p className="text-sm text-gray-600">{inspection.driverName}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-900">
                    {new Date(inspection.createdAt).toLocaleDateString('es-CO')}
                  </p>
                  <p className="text-sm text-gray-600">
                    {new Date(inspection.createdAt).toLocaleTimeString('es-CO', { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </p>
                  {inspection.defects.length > 0 && (
                    <span className="inline-flex items-center px-2 py-1 text-xs font-medium rounded-full bg-orange-100 text-orange-800">
                      {inspection.defects.length} defecto{inspection.defects.length > 1 ? 's' : ''}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500 text-center py-8">No hay inspecciones disponibles</p>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;