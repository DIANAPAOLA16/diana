import React, { useState } from 'react';
import { Plus, Car, Edit, Trash2, Save, X } from 'lucide-react';
import { VehicleInfo, VehicleDocument } from '../../types';

interface VehicleManagerProps {
  vehicles: VehicleInfo[];
  onVehicleAdd: (vehicle: VehicleInfo) => void;
  onVehicleUpdate: (vehicle: VehicleInfo) => void;
  onVehicleDelete: (plate: string) => void;
}

const VehicleManager: React.FC<VehicleManagerProps> = ({
  vehicles,
  onVehicleAdd,
  onVehicleUpdate,
  onVehicleDelete
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<VehicleInfo | null>(null);
  const [formData, setFormData] = useState<VehicleInfo>({
    plate: '',
    brand: '',
    model: '',
    year: new Date().getFullYear(),
    vin: '',
    color: '',
    fuelType: 'Diesel',
    documents: []
  });

  const documentTypes = ['SOAT', 'Tecnomecánica', 'Tarjeta de Propiedad', 'Revisión de Gases'];
  const fuelTypes = ['Diesel', 'Gasolina', 'Gas Natural', 'Eléctrico'];

  const resetForm = () => {
    setFormData({
      plate: '',
      brand: '',
      model: '',
      year: new Date().getFullYear(),
      vin: '',
      color: '',
      fuelType: 'Diesel',
      documents: []
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingVehicle) {
      onVehicleUpdate(formData);
      setEditingVehicle(null);
    } else {
      onVehicleAdd(formData);
      setShowAddForm(false);
    }
    
    resetForm();
  };

  const handleEdit = (vehicle: VehicleInfo) => {
    setFormData(vehicle);
    setEditingVehicle(vehicle);
    setShowAddForm(true);
  };

  const handleCancel = () => {
    setShowAddForm(false);
    setEditingVehicle(null);
    resetForm();
  };

  const addDocument = () => {
    const newDocument: VehicleDocument = {
      type: documentTypes[0],
      isValid: true,
      expirationDate: '',
      daysUntilExpiration: 0,
      documentNumber: ''
    };
    
    setFormData(prev => ({
      ...prev,
      documents: [...prev.documents, newDocument]
    }));
  };

  const updateDocument = (index: number, field: keyof VehicleDocument, value: any) => {
    setFormData(prev => ({
      ...prev,
      documents: prev.documents.map((doc, i) => 
        i === index ? { ...doc, [field]: value } : doc
      )
    }));
  };

  const removeDocument = (index: number) => {
    setFormData(prev => ({
      ...prev,
      documents: prev.documents.filter((_, i) => i !== index)
    }));
  };

  const calculateDaysUntilExpiration = (expirationDate: string) => {
    if (!expirationDate) return 0;
    const today = new Date();
    const expDate = new Date(expirationDate);
    const diffTime = expDate.getTime() - today.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Gestión de Vehículos</h2>
          <p className="text-gray-600">Administra la flota de vehículos y su documentación</p>
        </div>
        <button
          onClick={() => setShowAddForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Añadir Vehículo
        </button>
      </div>

      {/* Lista de vehículos */}
      <div className="grid gap-4">
        {vehicles.map((vehicle) => (
          <div key={vehicle.plate} className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm">
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-3">
                <div className="bg-blue-100 p-2 rounded-lg">
                  <Car className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 text-lg">{vehicle.plate}</h3>
                  <p className="text-gray-600">{vehicle.brand} {vehicle.model} ({vehicle.year})</p>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => handleEdit(vehicle)}
                  className="p-2 text-blue-600 hover:bg-blue-100 rounded transition-colors"
                >
                  <Edit className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onVehicleDelete(vehicle.plate)}
                  className="p-2 text-red-600 hover:bg-red-100 rounded transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div>
                <p className="text-sm text-gray-500">VIN</p>
                <p className="font-mono text-sm">{vehicle.vin}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Color</p>
                <p className="text-sm">{vehicle.color}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Combustible</p>
                <p className="text-sm">{vehicle.fuelType}</p>
              </div>
            </div>

            {/* Documentos */}
            <div>
              <p className="text-sm font-medium text-gray-700 mb-2">Documentos</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {vehicle.documents.map((doc, index) => (
                  <div key={index} className={`p-2 rounded text-xs ${
                    !doc.isValid ? 'bg-red-100 text-red-800' :
                    doc.daysUntilExpiration <= 30 ? 'bg-yellow-100 text-yellow-800' :
                    'bg-green-100 text-green-800'
                  }`}>
                    <div className="flex justify-between">
                      <span className="font-medium">{doc.type}</span>
                      <span>{doc.isValid ? 'Vigente' : 'Vencido'}</span>
                    </div>
                    <div className="text-xs opacity-75">
                      Vence: {doc.expirationDate}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      {vehicles.length === 0 && (
        <div className="text-center py-12">
          <Car className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600 text-lg">No hay vehículos registrados</p>
          <p className="text-gray-400">Añade vehículos para gestionar su documentación</p>
        </div>
      )}

      {/* Formulario de añadir/editar */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-gray-900">
                  {editingVehicle ? 'Editar Vehículo' : 'Añadir Nuevo Vehículo'}
                </h3>
                <button onClick={handleCancel} className="text-gray-500 hover:text-gray-700">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Información básica */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Placa *
                    </label>
                    <input
                      type="text"
                      value={formData.plate}
                      onChange={(e) => setFormData({ ...formData, plate: e.target.value.toUpperCase() })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Marca *
                    </label>
                    <input
                      type="text"
                      value={formData.brand}
                      onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Modelo *
                    </label>
                    <input
                      type="text"
                      value={formData.model}
                      onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Año *
                    </label>
                    <input
                      type="number"
                      value={formData.year}
                      onChange={(e) => setFormData({ ...formData, year: parseInt(e.target.value) })}
                      min="1990"
                      max={new Date().getFullYear() + 1}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      VIN *
                    </label>
                    <input
                      type="text"
                      value={formData.vin}
                      onChange={(e) => setFormData({ ...formData, vin: e.target.value.toUpperCase() })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent font-mono"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Color *
                    </label>
                    <input
                      type="text"
                      value={formData.color}
                      onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Tipo de Combustible *
                    </label>
                    <select
                      value={formData.fuelType}
                      onChange={(e) => setFormData({ ...formData, fuelType: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      required
                    >
                      {fuelTypes.map(type => (
                        <option key={type} value={type}>{type}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Documentos */}
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <h4 className="text-lg font-semibold text-gray-900">Documentos</h4>
                    <button
                      type="button"
                      onClick={addDocument}
                      className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                      Añadir Documento
                    </button>
                  </div>

                  <div className="space-y-4">
                    {formData.documents.map((doc, index) => (
                      <div key={index} className="p-4 border border-gray-200 rounded-lg">
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Tipo de Documento
                            </label>
                            <select
                              value={doc.type}
                              onChange={(e) => updateDocument(index, 'type', e.target.value)}
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                            >
                              {documentTypes.map(type => (
                                <option key={type} value={type}>{type}</option>
                              ))}
                            </select>
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Número de Documento
                            </label>
                            <input
                              type="text"
                              value={doc.documentNumber || ''}
                              onChange={(e) => updateDocument(index, 'documentNumber', e.target.value)}
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Fecha de Vencimiento
                            </label>
                            <input
                              type="date"
                              value={doc.expirationDate}
                              onChange={(e) => {
                                const days = calculateDaysUntilExpiration(e.target.value);
                                updateDocument(index, 'expirationDate', e.target.value);
                                updateDocument(index, 'daysUntilExpiration', days);
                                updateDocument(index, 'isValid', days > 0);
                              }}
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                            />
                          </div>
                          <div className="flex items-end">
                            <button
                              type="button"
                              onClick={() => removeDocument(index)}
                              className="p-2 text-red-600 hover:bg-red-100 rounded transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Botones */}
                <div className="flex justify-end gap-4">
                  <button
                    type="button"
                    onClick={handleCancel}
                    className="px-4 py-2 text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300 transition-colors"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
                  >
                    <Save className="w-4 h-4" />
                    {editingVehicle ? 'Actualizar' : 'Guardar'} Vehículo
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VehicleManager;