import React, { useState } from 'react';
import { Calendar, User, FileText, AlertTriangle, CheckCircle, Eye, Search, Filter } from 'lucide-react';
import { TruckInspection } from '../../types';

interface InspectionsListProps {
  inspections: TruckInspection[];
}

const InspectionsList: React.FC<InspectionsListProps> = ({ inspections }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedInspection, setSelectedInspection] = useState<TruckInspection | null>(null);
  const [filterDefects, setFilterDefects] = useState<'all' | 'with-defects' | 'no-defects'>('all');

  const filteredInspections = inspections.filter(inspection => {
    const matchesSearch = 
      inspection.plate.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inspection.driverName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inspection.vehicleInfo.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inspection.vehicleInfo.model.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesFilter = 
      filterDefects === 'all' ||
      (filterDefects === 'with-defects' && inspection.defects.length > 0) ||
      (filterDefects === 'no-defects' && inspection.defects.length === 0);

    return matchesSearch && matchesFilter;
  });

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-CO', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getDefectSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-orange-100 text-orange-800';
      case 'low': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getDefectSeverityLabel = (severity: string) => {
    switch (severity) {
      case 'high': return 'Grave';
      case 'medium': return 'Moderado';
      case 'low': return 'Leve';
      default: return severity;
    }
  };

  if (inspections.length === 0) {
    return (
      <div className="text-center py-12">
        <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-600 text-lg">No hay inspecciones registradas</p>
        <p className="text-gray-400">Las inspecciones aparecerán aquí cuando los conductores completen el formulario</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Filtros y búsqueda */}
      <div className="bg-white p-4 rounded-lg shadow-sm border">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar por placa, conductor, marca o modelo..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Filter className="w-5 h-5 text-gray-500" />
            <select
              value={filterDefects}
              onChange={(e) => setFilterDefects(e.target.value as 'all' | 'with-defects' | 'no-defects')}
              className="px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              <option value="all">Todas las inspecciones</option>
              <option value="with-defects">Con defectos</option>
              <option value="no-defects">Sin defectos</option>
            </select>
          </div>
        </div>
      </div>

      <h3 className="text-xl font-semibold text-gray-900">
        Inspecciones Registradas ({filteredInspections.length})
      </h3>
      
      <div className="grid gap-4">
        {filteredInspections.map((inspection) => (
          <div key={inspection.id} className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
              <div className="flex items-center gap-3">
                <div className="bg-green-100 p-2 rounded-lg">
                  <User className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 text-lg">{inspection.plate}</h4>
                  <p className="text-gray-600">{inspection.driverName}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-gray-500" />
                    <span className="text-sm text-gray-600">{formatDate(inspection.createdAt)}</span>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedInspection(inspection)}
                  className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                >
                  <Eye className="w-4 h-4" />
                  Ver Detalles
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
              <div>
                <p className="text-sm text-gray-500 mb-1">Vehículo</p>
                <p className="text-sm font-medium text-gray-900">
                  {inspection.vehicleInfo.brand} {inspection.vehicleInfo.model} ({inspection.vehicleInfo.year})
                </p>
              </div>
              
              <div>
                <p className="text-sm text-gray-500 mb-1">Kilometraje</p>
                <p className="text-sm font-medium text-gray-900">{inspection.currentKilometers.toLocaleString()} km</p>
              </div>
              
              <div>
                <p className="text-sm text-gray-500 mb-1">Defectos</p>
                <div className="flex items-center gap-2">
                  {inspection.defects.length > 0 ? (
                    <span className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium rounded-full bg-orange-100 text-orange-800">
                      <AlertTriangle className="w-3 h-3" />
                      {inspection.defects.length} defecto{inspection.defects.length > 1 ? 's' : ''}
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">
                      <CheckCircle className="w-3 h-3" />
                      Sin defectos
                    </span>
                  )}
                </div>
              </div>

              <div>
                <p className="text-sm text-gray-500 mb-1">Checklist</p>
                <div className="flex items-center gap-1">
                  {Object.values(inspection.checklist).every(Boolean) ? (
                    <span className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">
                      <CheckCircle className="w-3 h-3" />
                      Completo
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium rounded-full bg-yellow-100 text-yellow-800">
                      <AlertTriangle className="w-3 h-3" />
                      Incompleto
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Defectos graves destacados */}
            {inspection.defects.filter(d => d.severity === 'high').length > 0 && (
              <div className="mt-4 p-3 bg-red-50 rounded-lg border border-red-200">
                <p className="text-sm font-medium text-red-900 mb-2">⚠️ Defectos Graves Encontrados:</p>
                <div className="space-y-1">
                  {inspection.defects.filter(d => d.severity === 'high').map((defect, index) => (
                    <p key={index} className="text-sm text-red-800">
                      • {defect.location}: {defect.description}
                    </p>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Modal de detalles */}
      {selectedInspection && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-gray-900">
                  Detalles de Inspección - {selectedInspection.plate}
                </h3>
                <button
                  onClick={() => setSelectedInspection(null)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-6">
                {/* Información básica */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Información del Conductor</h4>
                    <p><strong>Nombre:</strong> {selectedInspection.driverName}</p>
                    <p><strong>Licencia:</strong> {selectedInspection.driverLicense}</p>
                    <p><strong>Firma:</strong> {selectedInspection.driverSignature}</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Información del Vehículo</h4>
                    <p><strong>Marca/Modelo:</strong> {selectedInspection.vehicleInfo.brand} {selectedInspection.vehicleInfo.model}</p>
                    <p><strong>Año:</strong> {selectedInspection.vehicleInfo.year}</p>
                    <p><strong>VIN:</strong> {selectedInspection.vehicleInfo.vin}</p>
                  </div>
                </div>

                {/* Kilometraje */}
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Kilometraje y Mantenimiento</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <p><strong>Kilometraje Actual:</strong> {selectedInspection.currentKilometers.toLocaleString()} km</p>
                    <p><strong>Próximo Servicio:</strong> {selectedInspection.nextServiceKm.toLocaleString()} km</p>
                    <p><strong>Fecha Próximo Servicio:</strong> {selectedInspection.nextServiceDate}</p>
                  </div>
                </div>

                {/* Checklist */}
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Checklist del Conductor</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { key: 'tiresGoodCondition', label: 'Neumáticos en buen estado' },
                      { key: 'bodyNoDamage', label: 'Carrocería sin daños graves' },
                      { key: 'lightsOperational', label: 'Luces y señalización operativas' },
                      { key: 'fullTank', label: 'Vehículo entregado con tanque lleno' }
                    ].map((item) => (
                      <div key={item.key} className="flex items-center gap-2">
                        {selectedInspection.checklist[item.key as keyof typeof selectedInspection.checklist] ? (
                          <CheckCircle className="w-4 h-4 text-green-600" />
                        ) : (
                          <AlertTriangle className="w-4 h-4 text-red-600" />
                        )}
                        <span className="text-sm">{item.label}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Defectos */}
                {selectedInspection.defects.length > 0 && (
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Defectos Encontrados</h4>
                    <div className="space-y-2">
                      {selectedInspection.defects.map((defect, index) => (
                        <div key={index} className="p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-2 mb-1">
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${getDefectSeverityColor(defect.severity)}`}>
                              {getDefectSeverityLabel(defect.severity)}
                            </span>
                            <span className="text-sm font-medium">{defect.location}</span>
                          </div>
                          <p className="text-sm text-gray-700">{defect.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Fotos */}
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Fotos del Vehículo</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {Object.entries(selectedInspection.photos).map(([key, photo]) => (
                      photo && (
                        <div key={key}>
                          <p className="text-sm text-gray-600 mb-1 capitalize">
                            {key.replace(/([A-Z])/g, ' $1').trim()}
                          </p>
                          <img
                            src={photo}
                            alt={key}
                            className="w-full h-32 object-cover rounded-lg border"
                          />
                        </div>
                      )
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default InspectionsList;