import React, { useState } from 'react';
import { Search, Loader2 } from 'lucide-react';
import { VehicleInfo } from '../../types';

interface PlateInputProps {
  onVehicleFound: (vehicleInfo: VehicleInfo) => void;
  onPlateChange: (plate: string) => void;
  plate: string;
}

const PlateInput: React.FC<PlateInputProps> = ({ onVehicleFound, onPlateChange, plate }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const mockVehicleDatabase = {
    'ABC123': {
      plate: 'ABC123',
      brand: 'Chevrolet',
      model: 'NPR',
      year: 2020,
      vin: '1GKEK13T8VJ123456',
      color: 'Blanco',
      fuelType: 'Diesel',
      documents: [
        {
          type: 'SOAT',
          isValid: true,
          expirationDate: '2024-12-15',
          daysUntilExpiration: 45,
          documentNumber: 'SOAT-2024-001'
        },
        {
          type: 'Tecnomecánica',
          isValid: true,
          expirationDate: '2024-11-20',
          daysUntilExpiration: 20,
          documentNumber: 'TEC-2024-001'
        },
        {
          type: 'Tarjeta de Propiedad',
          isValid: true,
          expirationDate: '2025-03-10',
          daysUntilExpiration: 150,
          documentNumber: 'TP-2024-001'
        },
        {
          type: 'Revisión de Gases',
          isValid: false,
          expirationDate: '2024-09-30',
          daysUntilExpiration: -30,
          documentNumber: 'RG-2024-001'
        }
      ]
    },
    'DEF456': {
      plate: 'DEF456',
      brand: 'Isuzu',
      model: 'FRR',
      year: 2019,
      vin: '2ISUZU456789012',
      color: 'Azul',
      fuelType: 'Diesel',
      documents: [
        {
          type: 'SOAT',
          isValid: true,
          expirationDate: '2024-10-25',
          daysUntilExpiration: 5,
          documentNumber: 'SOAT-2024-002'
        },
        {
          type: 'Tecnomecánica',
          isValid: true,
          expirationDate: '2024-12-01',
          daysUntilExpiration: 61,
          documentNumber: 'TEC-2024-002'
        },
        {
          type: 'Tarjeta de Propiedad',
          isValid: true,
          expirationDate: '2025-01-15',
          daysUntilExpiration: 106,
          documentNumber: 'TP-2024-002'
        },
        {
          type: 'Revisión de Gases',
          isValid: true,
          expirationDate: '2024-11-10',
          daysUntilExpiration: 10,
          documentNumber: 'RG-2024-002'
        }
      ]
    }
  };

  const searchVehicle = async (plateNumber: string) => {
    if (plateNumber.length < 6) return;

    setLoading(true);
    setError('');

    try {
      // Simular delay de API
      await new Promise(resolve => setTimeout(resolve, 1500));

      const vehicleInfo = mockVehicleDatabase[plateNumber as keyof typeof mockVehicleDatabase];
      
      if (vehicleInfo) {
        onVehicleFound(vehicleInfo);
      } else {
        setError('Vehículo no encontrado en la base de datos');
      }
    } catch (err) {
      setError('Error al consultar la información del vehículo');
    } finally {
      setLoading(false);
    }
  };

  const handlePlateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newPlate = e.target.value.toUpperCase();
    onPlateChange(newPlate);
    
    if (newPlate.length >= 6) {
      searchVehicle(newPlate);
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Placa del Vehículo *
        </label>
        <div className="relative">
          <input
            type="text"
            value={plate}
            onChange={handlePlateChange}
            placeholder="Ej: ABC123"
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-lg font-mono uppercase"
            className="w-full pl-10 pr-4 py-3 border border-florius-gray-300 rounded-lg focus:ring-2 focus:ring-florius-primary focus:border-transparent text-lg font-mono uppercase"
            maxLength={6}
            required
          />
          <Search className="absolute left-3 top-3.5 w-5 h-5 text-gray-400" />
          {loading && (
            <Loader2 className="absolute right-3 top-3.5 w-5 h-5 text-florius-primary animate-spin" />
          )}
        </div>
        
        {loading && (
          <div className="mt-2 flex items-center gap-2 text-florius-primary">
            <span className="text-sm">Consultando información del vehículo...</span>
          </div>
        )}
        
        {error && (
          <div className="mt-2 text-red-600 text-sm">
            {error}
          </div>
        )}
      </div>
    </div>
  );
};

export default PlateInput;