import React, { useState } from 'react';
import { User, Calendar, Gauge, Settings, Camera, CheckSquare, FileSignature } from 'lucide-react';
import PlateInput from './PlateInput';
import VehicleInfoDisplay from './VehicleInfoDisplay';
import PhotoUpload from './PhotoUpload';
import DefectManager from './DefectManager';
import { TruckInspection, VehicleInfo, VehiclePhotos, VehicleDefect, DriverChecklist } from '../../types';

interface DriverInspectionFormProps {
  onSubmit: (inspection: TruckInspection) => void;
}

const DriverInspectionForm: React.FC<DriverInspectionFormProps> = ({ onSubmit }) => {
  const [plate, setPlate] = useState('');
  const [vehicleInfo, setVehicleInfo] = useState<VehicleInfo | null>(null);
  const [formData, setFormData] = useState({
    driverName: '',
    driverLicense: '',
    currentKilometers: '',
    nextServiceKm: '',
    nextServiceDate: '',
    driverSignature: ''
  });
  
  const [photos, setPhotos] = useState<VehiclePhotos>({});
  const [defects, setDefects] = useState<VehicleDefect[]>([]);
  const [checklist, setChecklist] = useState<DriverChecklist>({
    tiresGoodCondition: false,
    bodyNoDamage: false,
    lightsOperational: false,
    fullTank: false
  });

  const handleVehicleFound = (info: VehicleInfo) => {
    setVehicleInfo(info);
  };

  const handlePhotoChange = (photoType: keyof VehiclePhotos, photo: string | undefined) => {
    setPhotos(prev => ({
      ...prev,
      [photoType]: photo
    }));
  };

  const handleChecklistChange = (item: keyof DriverChecklist, checked: boolean) => {
    setChecklist(prev => ({
      ...prev,
      [item]: checked
    }));
  };

  const calculateNextService = (currentKm: number) => {
    const serviceInterval = 10000; // Cada 10,000 km
    return currentKm + serviceInterval;
  };

  const handleCurrentKmChange = (value: string) => {
    setFormData(prev => ({ ...prev, currentKilometers: value }));
    
    if (value) {
      const currentKm = parseInt(value);
      const nextServiceKm = calculateNextService(currentKm);
      setFormData(prev => ({ ...prev, nextServiceKm: nextServiceKm.toString() }));
      
      // Calcular fecha aproximada del próximo servicio (asumiendo 1000 km por mes)
      const monthsToService = Math.ceil((nextServiceKm - currentKm) / 1000);
      const nextServiceDate = new Date();
      nextServiceDate.setMonth(nextServiceDate.getMonth() + monthsToService);
      setFormData(prev => ({ 
        ...prev, 
        nextServiceDate: nextServiceDate.toISOString().split('T')[0] 
      }));
    }
  };

  const isFormValid = () => {
    return (
      vehicleInfo &&
      formData.driverName &&
      formData.driverLicense &&
      formData.currentKilometers &&
      formData.driverSignature &&
      photos.front &&
      photos.back &&
      photos.leftSide &&
      photos.rightSide &&
      photos.interior &&
      photos.dashboard &&
      Object.values(checklist).every(Boolean)
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!vehicleInfo || !isFormValid()) return;

    const inspection: TruckInspection = {
      id: Date.now().toString(),
      plate,
      driverName: formData.driverName,
      driverLicense: formData.driverLicense,
      currentKilometers: parseInt(formData.currentKilometers),
      nextServiceKm: parseInt(formData.nextServiceKm),
      nextServiceDate: formData.nextServiceDate,
      vehicleInfo,
      photos,
      defects,
      checklist,
      driverSignature: formData.driverSignature,
      inspectionDate: new Date().toISOString().split('T')[0],
      createdAt: new Date().toISOString()
    };

    onSubmit(inspection);

    // Reset form
    setPlate('');
    setVehicleInfo(null);
    setFormData({
      driverName: '',
      driverLicense: '',
      currentKilometers: '',
      nextServiceKm: '',
      nextServiceDate: '',
      driverSignature: ''
    });
    setPhotos({});
    setDefects([]);
    setChecklist({
      tiresGoodCondition: false,
      bodyNoDamage: false,
      lightsOperational: false,
      fullTank: false
    });
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-lg">
      <div className="flex items-center gap-3 mb-6">
        <div className="bg-florius-light p-3 rounded-lg">
          <User className="w-8 h-8 text-florius-primary" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-florius-dark">Inspección de Vehículo</h2>
          <p className="text-florius-secondary">Checklist de Entrega / Recepción de Vehículo</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Búsqueda de Placa */}
        <PlateInput
          plate={plate}
          onPlateChange={setPlate}
          onVehicleFound={handleVehicleFound}
        />

        {/* Información del Vehículo */}
        {vehicleInfo && (
          <VehicleInfoDisplay vehicleInfo={vehicleInfo} />
        )}

        {vehicleInfo && (
          <>
            {/* Información del Conductor */}
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Información del Conductor</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nombre Completo *
                  </label>
                  <input
                    type="text"
                    value={formData.driverName}
                    onChange={(e) => setFormData({ ...formData, driverName: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Número de Licencia *
                  </label>
                  <input
                    type="text"
                    value={formData.driverLicense}
                    onChange={(e) => setFormData({ ...formData, driverLicense: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Kilometraje y Servicio */}
            <div className="bg-gray-50 p-6 rounded-lg">
              <div className="flex items-center gap-2 mb-4">
                <Gauge className="w-5 h-5 text-blue-600" />
                <h3 className="text-lg font-semibold text-gray-900">Kilometraje y Mantenimiento</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Kilometraje Actual *
                  </label>
                  <input
                    type="number"
                    value={formData.currentKilometers}
                    onChange={(e) => handleCurrentKmChange(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Próximo Servicio (Km)
                  </label>
                  <input
                    type="number"
                    value={formData.nextServiceKm}
                    readOnly
                    className="w-full px-4 py-2 border border-gray-300 rounded-md bg-gray-100"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Fecha Próximo Servicio
                  </label>
                  <input
                    type="date"
                    value={formData.nextServiceDate}
                    onChange={(e) => setFormData({ ...formData, nextServiceDate: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>
              </div>
            </div>

            {/* Fotos del Vehículo */}
            <div className="bg-gray-50 p-6 rounded-lg">
              <div className="flex items-center gap-2 mb-4">
                <Camera className="w-5 h-5 text-purple-600" />
                <h3 className="text-lg font-semibold text-gray-900">Fotos del Vehículo</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <PhotoUpload
                  label="Foto Frontal"
                  photo={photos.front}
                  onPhotoChange={(photo) => handlePhotoChange('front', photo)}
                  required
                />
                <PhotoUpload
                  label="Foto Trasera"
                  photo={photos.back}
                  onPhotoChange={(photo) => handlePhotoChange('back', photo)}
                  required
                />
                <PhotoUpload
                  label="Foto Lateral Izquierda"
                  photo={photos.leftSide}
                  onPhotoChange={(photo) => handlePhotoChange('leftSide', photo)}
                  required
                />
                <PhotoUpload
                  label="Foto Lateral Derecha"
                  photo={photos.rightSide}
                  onPhotoChange={(photo) => handlePhotoChange('rightSide', photo)}
                  required
                />
                <PhotoUpload
                  label="Foto Interior Cabina"
                  photo={photos.interior}
                  onPhotoChange={(photo) => handlePhotoChange('interior', photo)}
                  required
                />
                <PhotoUpload
                  label="Foto Tablero / Odómetro"
                  photo={photos.dashboard}
                  onPhotoChange={(photo) => handlePhotoChange('dashboard', photo)}
                  required
                />
              </div>
            </div>

            {/* Gestión de Defectos */}
            <div className="bg-gray-50 p-6 rounded-lg">
              <DefectManager defects={defects} onDefectsChange={setDefects} />
            </div>

            {/* Checklist del Conductor */}
            <div className="bg-gray-50 p-6 rounded-lg">
              <div className="flex items-center gap-2 mb-4">
                <CheckSquare className="w-5 h-5 text-green-600" />
                <h3 className="text-lg font-semibold text-gray-900">Checklist del Conductor</h3>
              </div>
              <div className="space-y-3">
                {[
                  { key: 'tiresGoodCondition', label: 'Neumáticos en buen estado' },
                  { key: 'bodyNoDamage', label: 'Carrocería sin daños graves' },
                  { key: 'lightsOperational', label: 'Luces y señalización operativas' },
                  { key: 'fullTank', label: 'Vehículo entregado con tanque lleno' }
                ].map((item) => (
                  <label key={item.key} className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={checklist[item.key as keyof DriverChecklist]}
                      onChange={(e) => handleChecklistChange(item.key as keyof DriverChecklist, e.target.checked)}
                      className="w-5 h-5 text-green-600 border-gray-300 rounded focus:ring-green-500"
                      required
                    />
                    <span className="text-gray-900">{item.label}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Firma y Fecha */}
            <div className="bg-gray-50 p-6 rounded-lg">
              <div className="flex items-center gap-2 mb-4">
                <FileSignature className="w-5 h-5 text-indigo-600" />
                <h3 className="text-lg font-semibold text-gray-900">Firma y Confirmación</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Firma (escriba su nombre completo) *
                  </label>
                  <input
                    type="text"
                    value={formData.driverSignature}
                    onChange={(e) => setFormData({ ...formData, driverSignature: e.target.value })}
                    placeholder="Nombre completo como firma"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Fecha
                  </label>
                  <input
                    type="date"
                    value={new Date().toISOString().split('T')[0]}
                    readOnly
                    className="w-full px-4 py-2 border border-gray-300 rounded-md bg-gray-100"
                  />
                </div>
              </div>
              <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
                <p className="text-sm text-blue-800">
                  <strong>Declaración:</strong> Con mi firma reconozco haber inspeccionado el vehículo y acepto la responsabilidad de su uso y cuidado de acuerdo con las políticas corporativas.
                </p>
              </div>
            </div>

            {/* Botón de Envío */}
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={!isFormValid()}
                className={`px-8 py-3 rounded-lg font-medium transition-colors ${
                  isFormValid()
                    ? 'bg-green-600 text-white hover:bg-green-700 focus:ring-2 focus:ring-green-500'
                    : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                }`}
              >
                Completar Inspección
              </button>
            </div>
          </>
        )}
      </form>
    </div>
  );
};

export default DriverInspectionForm;