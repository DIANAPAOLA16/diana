import React, { useState } from 'react';
import { Plus, Trash2, AlertTriangle } from 'lucide-react';
import { VehicleDefect } from '../../types';

interface DefectManagerProps {
  defects: VehicleDefect[];
  onDefectsChange: (defects: VehicleDefect[]) => void;
}

const DefectManager: React.FC<DefectManagerProps> = ({ defects, onDefectsChange }) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [newDefect, setNewDefect] = useState({
    description: '',
    severity: 'medium' as 'low' | 'medium' | 'high',
    location: ''
  });

  const severityOptions = [
    { value: 'low', label: 'Leve', color: 'bg-yellow-100 text-yellow-800' },
    { value: 'medium', label: 'Moderado', color: 'bg-orange-100 text-orange-800' },
    { value: 'high', label: 'Grave', color: 'bg-red-100 text-red-800' }
  ];

  const getSeverityColor = (severity: string) => {
    const option = severityOptions.find(opt => opt.value === severity);
    return option?.color || 'bg-gray-100 text-gray-800';
  };

  const getSeverityLabel = (severity: string) => {
    const option = severityOptions.find(opt => opt.value === severity);
    return option?.label || severity;
  };

  const handleAddDefect = () => {
    if (newDefect.description.trim() && newDefect.location.trim()) {
      const defect: VehicleDefect = {
        id: Date.now().toString(),
        ...newDefect
      };
      
      onDefectsChange([...defects, defect]);
      setNewDefect({ description: '', severity: 'medium', location: '' });
      setShowAddForm(false);
    }
  };

  const handleRemoveDefect = (id: string) => {
    onDefectsChange(defects.filter(defect => defect.id !== id));
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-orange-600" />
          <h3 className="text-lg font-semibold text-gray-900">Notificación de Defectos</h3>
        </div>
        <button
          type="button"
          onClick={() => setShowAddForm(true)}
          className="flex items-center gap-2 px-3 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Añadir Defecto
        </button>
      </div>

      <p className="text-sm text-gray-600">
        Registra aquí todos los defectos observados. Añade tantos como necesites.
      </p>

      {/* Lista de defectos existentes */}
      {defects.length > 0 && (
        <div className="space-y-3">
          {defects.map((defect) => (
            <div key={defect.id} className="bg-gray-50 p-4 rounded-lg border">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getSeverityColor(defect.severity)}`}>
                      {getSeverityLabel(defect.severity)}
                    </span>
                    <span className="text-sm text-gray-600">• {defect.location}</span>
                  </div>
                  <p className="text-gray-900">{defect.description}</p>
                </div>
                <button
                  type="button"
                  onClick={() => handleRemoveDefect(defect.id)}
                  className="p-1 text-red-600 hover:bg-red-100 rounded transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Formulario para añadir defecto */}
      {showAddForm && (
        <div className="bg-white p-4 border border-orange-200 rounded-lg">
          <h4 className="font-medium text-gray-900 mb-3">Nuevo Defecto</h4>
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Ubicación del defecto *
              </label>
              <input
                type="text"
                value={newDefect.location}
                onChange={(e) => setNewDefect({ ...newDefect, location: e.target.value })}
                placeholder="Ej: Puerta delantera izquierda, Neumático trasero derecho"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Severidad *
              </label>
              <select
                value={newDefect.severity}
                onChange={(e) => setNewDefect({ ...newDefect, severity: e.target.value as 'low' | 'medium' | 'high' })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              >
                {severityOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Descripción del defecto *
              </label>
              <textarea
                value={newDefect.description}
                onChange={(e) => setNewDefect({ ...newDefect, description: e.target.value })}
                placeholder="Describe detalladamente el defecto observado"
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
            </div>
            
            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleAddDefect}
                className="px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700 transition-colors"
              >
                Añadir Defecto
              </button>
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 transition-colors"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

      {defects.length === 0 && !showAddForm && (
        <div className="text-center py-8 text-gray-500">
          <AlertTriangle className="w-12 h-12 text-gray-300 mx-auto mb-2" />
          <p>No se han registrado defectos</p>
          <p className="text-sm">Haz clic en "Añadir Defecto" si encuentras algún problema</p>
        </div>
      )}
    </div>
  );
};

export default DefectManager;