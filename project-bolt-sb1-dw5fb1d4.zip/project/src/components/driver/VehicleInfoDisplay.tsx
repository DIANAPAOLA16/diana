import React from 'react';
import { Car, FileText, AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import { VehicleInfo } from '../../types';

interface VehicleInfoDisplayProps {
  vehicleInfo: VehicleInfo;
}

const VehicleInfoDisplay: React.FC<VehicleInfoDisplayProps> = ({ vehicleInfo }) => {
  const getDocumentIcon = (doc: any) => {
    if (!doc.isValid) {
      return <AlertTriangle className="w-5 h-5 text-red-600" />;
    } else if (doc.daysUntilExpiration <= 30) {
      return <Clock className="w-5 h-5 text-yellow-600" />;
    } else {
      return <CheckCircle className="w-5 h-5 text-green-600" />;
    }
  };

  const getDocumentStatus = (doc: any) => {
    if (!doc.isValid) return 'Vencido';
    if (doc.daysUntilExpiration <= 30) return 'Por vencer';
    return 'Vigente';
  };

  const getDocumentColor = (doc: any) => {
    if (!doc.isValid) return 'bg-red-100 text-red-800 border-red-200';
    if (doc.daysUntilExpiration <= 30) return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    return 'bg-green-100 text-green-800 border-green-200';
  };

  return (
    <div className="space-y-6">
      {/* Información del Vehículo */}
      <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
        <div className="flex items-center gap-3 mb-4">
          <Car className="w-6 h-6 text-blue-600" />
          <h3 className="text-lg font-semibold text-blue-900">Información del Vehículo</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-blue-700 font-medium">Placa</p>
            <p className="text-lg font-bold text-blue-900">{vehicleInfo.plate}</p>
          </div>
          <div>
            <p className="text-sm text-blue-700 font-medium">Marca/Modelo</p>
            <p className="text-blue-900">{vehicleInfo.brand} {vehicleInfo.model}</p>
          </div>
          <div>
            <p className="text-sm text-blue-700 font-medium">Año</p>
            <p className="text-blue-900">{vehicleInfo.year}</p>
          </div>
          <div>
            <p className="text-sm text-blue-700 font-medium">Color</p>
            <p className="text-blue-900">{vehicleInfo.color}</p>
          </div>
          <div>
            <p className="text-sm text-blue-700 font-medium">VIN</p>
            <p className="text-blue-900 font-mono text-sm">{vehicleInfo.vin}</p>
          </div>
          <div>
            <p className="text-sm text-blue-700 font-medium">Combustible</p>
            <p className="text-blue-900">{vehicleInfo.fuelType}</p>
          </div>
        </div>
      </div>

      {/* Estado de Documentos */}
      <div className="bg-white p-6 rounded-lg border border-gray-200">
        <div className="flex items-center gap-3 mb-4">
          <FileText className="w-6 h-6 text-gray-600" />
          <h3 className="text-lg font-semibold text-gray-900">Estado de Documentos</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {vehicleInfo.documents.map((doc, index) => (
            <div key={index} className={`p-4 rounded-lg border ${getDocumentColor(doc)}`}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  {getDocumentIcon(doc)}
                  <span className="font-medium">{doc.type}</span>
                </div>
                <span className="text-xs font-medium px-2 py-1 rounded-full bg-white bg-opacity-50">
                  {getDocumentStatus(doc)}
                </span>
              </div>
              <div className="text-sm space-y-1">
                <p>Vence: {doc.expirationDate}</p>
                {doc.documentNumber && (
                  <p className="font-mono text-xs">No: {doc.documentNumber}</p>
                )}
                {doc.daysUntilExpiration > 0 && (
                  <p>Días restantes: {doc.daysUntilExpiration}</p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default VehicleInfoDisplay;