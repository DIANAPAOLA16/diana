import React, { useRef } from 'react';
import { Camera, Upload, X } from 'lucide-react';

interface PhotoUploadProps {
  label: string;
  photo?: string;
  onPhotoChange: (photo: string | undefined) => void;
  required?: boolean;
}

const PhotoUpload: React.FC<PhotoUploadProps> = ({ label, photo, onPhotoChange, required = false }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        onPhotoChange(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemovePhoto = () => {
    onPhotoChange(undefined);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-gray-700">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      
      {photo ? (
        <div className="relative">
          <img
            src={photo}
            alt={label}
            className="w-full h-48 object-cover rounded-lg border border-gray-300"
          />
          <button
            type="button"
            onClick={handleRemovePhoto}
            className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ) : (
        <div
          onClick={() => fileInputRef.current?.click()}
          className="w-full h-48 border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-green-400 hover:bg-green-50 transition-colors"
        >
          <Camera className="w-12 h-12 text-gray-400 mb-2" />
          <p className="text-gray-600 text-center">
            <span className="font-medium">Toca para tomar foto</span>
            <br />
            <span className="text-sm">o seleccionar archivo</span>
          </p>
          <Upload className="w-4 h-4 text-gray-400 mt-1" />
        </div>
      )}
      
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFileChange}
        className="hidden"
        required={required && !photo}
      />
    </div>
  );
};

export default PhotoUpload;