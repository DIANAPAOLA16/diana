import React, { useState } from 'react';
import { Truck, User, Calendar, Save } from 'lucide-react';

interface NewVehicleEntry {
  id: string;
  plate: string;
  driverName: string;
  driverLicense: string;
  company: string;
  purpose: string;
  estimatedDuration: string;
  contactPhone: string;
  observations: string;
  entryTime: string;
  createdAt: string;
}

interface NewVehicleFormProps {
  onSubmit: (entry: NewVehicleEntry) => void;
}

const NewVehicleForm: React.FC<NewVehicleFormProps> = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    plate: '',
    driverName: '',
    driverLicense: '',
    company: '',
    purpose: '',
    estimatedDuration: '',
    contactPhone: '',
    observations: ''
  });

  const purposeOptions = [
    'Entrega de mercancía',
    'Recolección de productos',
    'Servicio técnico',
    'Proveedor',
    'Visita comercial',
    'Mantenimiento',
    'Otro'
  ];

  const durationOptions = [
    '1-2 horas',
    '2-4 horas',
    '4-8 horas',
    'Todo el día',
    'Varios días'
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const entry: NewVehicleEntry = {
      id: Date.now().toString(),
      ...formData,
      entryTime: new Date().toISOString(),
      createdAt: new Date().toISOString()
    };
    
    onSubmit(entry);
    
    // Reset form
    setFormData({
      plate: '',
      driverName: '',
      driverLicense: '',
      company: '',
      purpose: '',
      estimatedDuration: '',
      contactPhone: '',
      observations: ''
    });
  };

  const isFormValid = formData.plate && formData.driverName && formData.driverLicense && 
                     formData.company && formData.purpose;

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-lg border border-florius-light">
      <div className="flex items-center gap-3 mb-6">
        <div className="bg-florius-light p-3 rounded-lg">
          <Truck className="w-8 h-8 text-florius-primary" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-florius-dark">Registro de Vehículo Nuevo/Externo</h2>
          <p className="text-florius-secondary">Registro rápido para vehículos externos o nuevos en la flota</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Placa del Vehículo */}
          <div>
            <label className="block text-sm font-medium text-florius-dark mb-2">
              Placa del Vehículo *
            </label>
            <input
              type="text"
              value={formData.plate}
              onChange={(e) => setFormData({ ...formData, plate: e.target.value.toUpperCase() })}
              placeholder="Ej: ABC123"
              className="w-full px-4 py-3 border border-florius-gray-300 rounded-lg focus:ring-2 focus:ring-florius-primary focus:border-transparent uppercase font-mono text-lg"
              required
            />
          </div>

          {/* Conductor */}
          <div>
            <label className="block text-sm font-medium text-florius-dark mb-2">
              Nombre del Conductor *
            </label>
            <div className="relative">
              <User className="absolute left-3 top-3.5 w-5 h-5 text-florius-gray-400" />
              <input
                type="text"
                value={formData.driverName}
                onChange={(e) => setFormData({ ...formData, driverName: e.target.value })}
                placeholder="Nombre completo"
                className="w-full pl-10 pr-4 py-3 border border-florius-gray-300 rounded-lg focus:ring-2 focus:ring-florius-primary focus:border-transparent"
                required
              />
            </div>
          </div>

          {/* Licencia de Conducir */}
          <div>
            <label className="block text-sm font-medium text-florius-dark mb-2">
              Número de Licencia *
            </label>
            <input
              type="text"
              value={formData.driverLicense}
              onChange={(e) => setFormData({ ...formData, driverLicense: e.target.value })}
              placeholder="Número de licencia"
              className="w-full px-4 py-3 border border-florius-gray-300 rounded-lg focus:ring-2 focus:ring-florius-primary focus:border-transparent"
              required
            />
          </div>

          {/* Empresa */}
          <div>
            <label className="block text-sm font-medium text-florius-dark mb-2">
              Empresa/Organización *
            </label>
            <input
              type="text"
              value={formData.company}
              onChange={(e) => setFormData({ ...formData, company: e.target.value })}
              placeholder="Nombre de la empresa"
              className="w-full px-4 py-3 border border-florius-gray-300 rounded-lg focus:ring-2 focus:ring-florius-primary focus:border-transparent"
              required
            />
          </div>

          {/* Propósito de la Visita */}
          <div>
            <label className="block text-sm font-medium text-florius-dark mb-2">
              Propósito de la Visita *
            </label>
            <select
              value={formData.purpose}
              onChange={(e) => setFormData({ ...formData, purpose: e.target.value })}
              className="w-full px-4 py-3 border border-florius-gray-300 rounded-lg focus:ring-2 focus:ring-florius-primary focus:border-transparent"
              required
            >
              <option value="">Seleccionar propósito</option>
              {purposeOptions.map((purpose) => (
                <option key={purpose} value={purpose}>
                  {purpose}
                </option>
              ))}
            </select>
          </div>

          {/* Duración Estimada */}
          <div>
            <label className="block text-sm font-medium text-florius-dark mb-2">
              Duración Estimada
            </label>
            <select
              value={formData.estimatedDuration}
              onChange={(e) => setFormData({ ...formData, estimatedDuration: e.target.value })}
              className="w-full px-4 py-3 border border-florius-gray-300 rounded-lg focus:ring-2 focus:ring-florius-primary focus:border-transparent"
            >
              <option value="">Seleccionar duración</option>
              {durationOptions.map((duration) => (
                <option key={duration} value={duration}>
                  {duration}
                </option>
              ))}
            </select>
          </div>

          {/* Teléfono de Contacto */}
          <div>
            <label className="block text-sm font-medium text-florius-dark mb-2">
              Teléfono de Contacto
            </label>
            <input
              type="tel"
              value={formData.contactPhone}
              onChange={(e) => setFormData({ ...formData, contactPhone: e.target.value })}
              placeholder="Número de contacto"
              className="w-full px-4 py-3 border border-florius-gray-300 rounded-lg focus:ring-2 focus:ring-florius-primary focus:border-transparent"
            />
          </div>

          {/* Fecha y Hora de Ingreso */}
          <div>
            <label className="block text-sm font-medium text-florius-dark mb-2">
              Fecha y Hora de Ingreso
            </label>
            <div className="relative">
              <Calendar className="absolute left-3 top-3.5 w-5 h-5 text-florius-gray-400" />
              <input
                type="datetime-local"
                value={new Date().toISOString().slice(0, 16)}
                readOnly
                className="w-full pl-10 pr-4 py-3 border border-florius-gray-300 rounded-lg bg-florius-gray-50"
              />
            </div>
          </div>
        </div>

        {/* Observaciones */}
        <div>
          <label className="block text-sm font-medium text-florius-dark mb-2">
            Observaciones
          </label>
          <textarea
            value={formData.observations}
            onChange={(e) => setFormData({ ...formData, observations: e.target.value })}
            placeholder="Observaciones adicionales sobre el vehículo, conductor o visita"
            rows={3}
            className="w-full px-4 py-3 border border-florius-gray-300 rounded-lg focus:ring-2 focus:ring-florius-primary focus:border-transparent"
          />
        </div>

        {/* Información Adicional */}
        <div className="bg-florius-light p-4 rounded-lg border border-florius-accent">
          <h3 className="font-medium text-florius-dark mb-2">Información Importante</h3>
          <ul className="text-sm text-florius-secondary space-y-1">
            <li>• El vehículo debe cumplir con todas las normas de seguridad</li>
            <li>• El conductor debe portar documentos de identificación válidos</li>
            <li>• Se debe respetar las áreas designadas para estacionamiento</li>
            <li>• Velocidad máxima dentro de las instalaciones: 20 km/h</li>
          </ul>
        </div>

        {/* Botón de Envío */}
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={!isFormValid}
            className={`flex items-center gap-2 px-8 py-3 rounded-lg font-medium transition-colors ${
              isFormValid
                ? 'bg-florius-primary text-white hover:bg-florius-dark focus:ring-2 focus:ring-florius-primary'
                : 'bg-florius-gray-300 text-florius-gray-500 cursor-not-allowed'
            }`}
          >
            <Save className="w-5 h-5" />
            Registrar Ingreso
          </button>
        </div>
      </form>
    </div>
  );
};

export default NewVehicleForm;