export interface VehicleDocument {
  type: string;
  isValid: boolean;
  expirationDate: string;
  daysUntilExpiration: number;
  documentNumber?: string;
}

export interface VehicleInfo {
  plate: string;
  brand: string;
  model: string;
  year: number;
  vin: string;
  color: string;
  fuelType: string;
  documents: VehicleDocument[];
}

export interface VehicleDefect {
  id: string;
  description: string;
  severity: 'low' | 'medium' | 'high';
  location: string;
}

export interface VehiclePhotos {
  front?: string;
  back?: string;
  leftSide?: string;
  rightSide?: string;
  interior?: string;
  dashboard?: string;
}

export interface DriverChecklist {
  tiresGoodCondition: boolean;
  bodyNoDamage: boolean;
  lightsOperational: boolean;
  fullTank: boolean;
}

export interface TruckInspection {
  id: string;
  plate: string;
  driverName: string;
  driverLicense: string;
  currentKilometers: number;
  nextServiceKm: number;
  nextServiceDate: string;
  vehicleInfo: VehicleInfo;
  photos: VehiclePhotos;
  defects: VehicleDefect[];
  checklist: DriverChecklist;
  driverSignature: string;
  inspectionDate: string;
  createdAt: string;
}

export interface AdminUser {
  username: string;
  password: string;
}