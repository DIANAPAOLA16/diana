import React, { useState } from 'react';
import { BarChart3, FileText, Settings } from 'lucide-react';
import Logo from './components/shared/Logo';
import Navigation from './components/shared/Navigation';
import NewVehicleForm from './components/newVehicle/NewVehicleForm';
import DriverInspectionForm from './components/driver/DriverInspectionForm';
import AdminLogin from './components/admin/AdminLogin';
import AdminDashboard from './components/admin/AdminDashboard';
import InspectionsList from './components/admin/InspectionsList';
import VehicleManager from './components/admin/VehicleManager';
import { useLocalStorage } from './hooks/useLocalStorage';
import { TruckInspection, VehicleInfo } from './types';

interface NewVehicleEntry {
  id: string;
  plate: string;
  driverName: string;
  driverLicense: string;
  company: string;
  purpose: string;
  estimatedDuration: string;
  contactPhone: string;
  observations: string;
  entryTime: string;
  createdAt: string;
}

type ViewType = 'new-vehicle' | 'inspection' | 'admin';
type AdminTabType = 'dashboard' | 'inspections' | 'vehicles';
function App() {
  const [inspections, setInspections] = useLocalStorage<TruckInspection[]>('truck-inspections', []);
  const [newVehicleEntries, setNewVehicleEntries] = useLocalStorage<NewVehicleEntry[]>('new-vehicle-entries', []);
  const [vehicles, setVehicles] = useLocalStorage<VehicleInfo[]>('vehicle-fleet', [
    // Datos de ejemplo
    {
      plate: 'ABC123',
      brand: 'Chevrolet',
      model: 'NPR',
      year: 2020,
      vin: '1GKEK13T8VJ123456',
      color: 'Blanco',
      fuelType: 'Diesel',
      documents: [
        {
          type: 'SOAT',
          isValid: true,
          expirationDate: '2024-12-15',
          daysUntilExpiration: 45,
          documentNumber: 'SOAT-2024-001'
        },
        {
          type: 'Tecnomecánica',
          isValid: true,
          expirationDate: '2024-11-20',
          daysUntilExpiration: 20,
          documentNumber: 'TEC-2024-001'
        },
        {
          type: 'Tarjeta de Propiedad',
          isValid: true,
          expirationDate: '2025-03-10',
          daysUntilExpiration: 150,
          documentNumber: 'TP-2024-001'
        },
        {
          type: 'Revisión de Gases',
          isValid: false,
          expirationDate: '2024-09-30',
          daysUntilExpiration: -30,
          documentNumber: 'RG-2024-001'
        }
      ]
    },
    {
      plate: 'DEF456',
      brand: 'Isuzu',
      model: 'FRR',
      year: 2019,
      vin: '2ISUZU456789012',
      color: 'Azul',
      fuelType: 'Diesel',
      documents: [
        {
          type: 'SOAT',
          isValid: true,
          expirationDate: '2024-10-25',
          daysUntilExpiration: 5,
          documentNumber: 'SOAT-2024-002'
        },
        {
          type: 'Tecnomecánica',
          isValid: true,
          expirationDate: '2024-12-01',
          daysUntilExpiration: 61,
          documentNumber: 'TEC-2024-002'
        },
        {
          type: 'Tarjeta de Propiedad',
          isValid: true,
          expirationDate: '2025-01-15',
          daysUntilExpiration: 106,
          documentNumber: 'TP-2024-002'
        },
        {
          type: 'Revisión de Gases',
          isValid: true,
          expirationDate: '2024-11-10',
          daysUntilExpiration: 10,
          documentNumber: 'RG-2024-002'
        }
      ]
    }
  ]);
  
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [currentView, setCurrentView] = useState<ViewType>('new-vehicle');
  const [activeAdminTab, setActiveAdminTab] = useState<AdminTabType>('dashboard');

  const handleInspectionSubmit = (inspection: TruckInspection) => {
    setInspections([inspection, ...inspections]);
    alert('Inspección registrada exitosamente');
  };

  const handleNewVehicleSubmit = (entry: NewVehicleEntry) => {
    setNewVehicleEntries([entry, ...newVehicleEntries]);
    alert('Vehículo registrado exitosamente');
  };

  const handleAdminLogin = (username: string, password: string) => {
    // Credenciales simples para demo
    if (username === 'admin' && password === 'admin123') {
      setIsAdminLoggedIn(true);
      return true;
    }
    return false;
  };

  const handleAdminLogout = () => {
    setIsAdminLoggedIn(false);
    setCurrentView('new-vehicle');
    setActiveAdminTab('dashboard');
  };

  const handleVehicleAdd = (vehicle: VehicleInfo) => {
    setVehicles([...vehicles, vehicle]);
  };

  const handleVehicleUpdate = (updatedVehicle: VehicleInfo) => {
    setVehicles(vehicles.map(v => v.plate === updatedVehicle.plate ? updatedVehicle : v));
  };

  const handleVehicleDelete = (plate: string) => {
    if (confirm('¿Estás seguro de que quieres eliminar este vehículo?')) {
      setVehicles(vehicles.filter(v => v.plate !== plate));
    }
  };

  const handleViewChange = (view: ViewType) => {
    if (view === 'admin' && !isAdminLoggedIn) {
      const success = handleAdminLogin('admin', 'admin123');
      if (success) {
        setCurrentView('admin');
      }
    } else {
      setCurrentView(view);
    }
  };
  const adminTabs = [
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
    { id: 'inspections', label: 'Inspecciones', icon: FileText },
    { id: 'vehicles', label: 'Vehículos', icon: Settings }
  ];







  if (currentView === 'admin' && !isAdminLoggedIn) {
    return <AdminLogin onLogin={handleAdminLogin} />;
  }

  return (
    <div className="min-h-screen bg-florius-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-florius-light">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Logo />
          </div>
        </div>
      </header>

      {/* Navigation */}
      <Navigation 
        currentView={currentView}
        onViewChange={handleViewChange}
        isAdmin={isAdminLoggedIn}
        onLogout={currentView === 'admin' ? handleAdminLogout : undefined}
      />

      {/* Admin Navigation */}
      {currentView === 'admin' && isAdminLoggedIn && (
        <nav className="bg-white border-b border-florius-light">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex space-x-8">
              {adminTabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveAdminTab(tab.id as AdminTabType)}
                    className={`flex items-center gap-2 px-3 py-4 text-sm font-medium border-b-2 transition-colors ${
                      activeAdminTab === tab.id
                        ? 'border-florius-primary text-florius-primary'
                        : 'border-transparent text-florius-secondary hover:text-florius-primary hover:border-florius-accent'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {tab.label}
                  </button>
                );
              })}
            </div>
          </div>
        </nav>
      )}

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {currentView === 'new-vehicle' && (
          <NewVehicleForm onSubmit={handleNewVehicleSubmit} />
        )}
        
        {currentView === 'inspection' && (
          <DriverInspectionForm onSubmit={handleInspectionSubmit} />
        )}
        
        {currentView === 'admin' && isAdminLoggedIn && (
          <>
            {activeAdminTab === 'dashboard' && <AdminDashboard inspections={inspections} />}
            {activeAdminTab === 'inspections' && <InspectionsList inspections={inspections} />}
            {activeAdminTab === 'vehicles' && (
              <VehicleManager
                vehicles={vehicles}
                onVehicleAdd={handleVehicleAdd}
                onVehicleUpdate={handleVehicleUpdate}
                onVehicleDelete={handleVehicleDelete}
              />
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-florius-light mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="text-center text-sm text-florius-secondary">
            <p>© 2024 Florius Flowers - Sistema de Registro Vehicular</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;